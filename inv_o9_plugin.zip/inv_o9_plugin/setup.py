from setuptools import setup, find_packages
import time
import os

setup(name='inv-o9-plugin',
      packages=['src'],
      include_package_data=True
      )
