# Copyright 2019 Nike, Inc. All rights reserved.
try:
    from setuptools import setup, find_packages
except ImportError:
    from distutils.core import setup

VERSION = "0.0.14"

with open("requirements.txt") as f:
    requirements = f.read().splitlines()

setup(
    name="inv-o9-plugin",
    version=VERSION,
    description="Test Package for testing o9 connectivity to artifactory",
    author="DSM IM",
    author_email="Lst-Technology.SCEF.DSM.IM-E2EInvFcst@nike.com",
    url="",
    zip_safe=False,
    include_package_data=True,
    packages=find_packages("src"),
    package_dir={"": "src"},
    install_requires=requirements,
)
